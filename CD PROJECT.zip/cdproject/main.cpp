#include <iostream>

extern int yyparse();

int main() {
    std::cout << "Enter expression (e.g., LCM x = 12, 18;):\n";
    yyparse();
    return 0;
}
